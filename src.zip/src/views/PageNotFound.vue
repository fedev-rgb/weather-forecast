<script setup>
</script>

<script>
export default {
  name: "PageNotFound",
};
</script>

<template>
    <div class="page-not-found">
      404 Page Not Found
    </div>
</template>
